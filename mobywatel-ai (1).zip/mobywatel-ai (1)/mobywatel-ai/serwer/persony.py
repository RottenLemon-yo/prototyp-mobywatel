# -*- coding: utf-8 -*-
"""Osoby demonstracyjne (fikcyjne). Każde zapytanie do agenta działa w kontekście jednej osoby:
ustaw(id) w wątku obsługującym zapytanie, P() zwraca jej dane."""
import threading

def pesel(rrmmdd, seria, plec):
    """Poprawny numer PESEL: data (miesiąc z przesunięciem dla roczników 2000+), 3 cyfry serii, cyfra płci, suma kontrolna."""
    s = rrmmdd + seria + str(plec)
    w = [1, 3, 7, 9, 1, 3, 7, 9, 1, 3]
    return s + str((10 - sum(int(c) * w[i] for i, c in enumerate(s)) % 10) % 10)

# Program MON „wGotowości”: 4 moduły po ok. 8 godzin, w jednostkach wojskowych, głównie w weekendy.
KURSY_W = lambda miasto, a, b, c: [
    dict(id='MED-2410', rodzaj='medyczny', termin='24.10.2026 (sobota), 9:00–17:00', miejsce='jednostka wojskowa, ' + a, wolne=6),
    dict(id='MED-0811', rodzaj='medyczny', termin='08.11.2026 (niedziela), 9:00–17:00', miejsce='jednostka wojskowa, ' + b, wolne=2),
    dict(id='PRZ-1411', rodzaj='przetrwania', termin='14.11.2026 (sobota), 8:00–16:00', miejsce='jednostka wojskowa, ' + c, wolne=11),
    dict(id='BEZ-0711', rodzaj='podstawowy', termin='07.11.2026 (sobota), 9:00–17:00', miejsce='jednostka wojskowa, ' + a, wolne=14),
    dict(id='CYB-1511', rodzaj='cyberhigiena', termin='15.11.2026 (niedziela), 9:00–17:00', miejsce='jednostka wojskowa, ' + a, wolne=40)]

# Ulgi z Karty Dużej Rodziny: ustawowe i ogólnopolskie (lokalnych partnerów nie zmyślamy, odsyłamy do wyszukiwarki Emp@tii).
KDR_ULGI = lambda miasto: [['PKP Intercity', 'rodzice 37% (miesięczny 49%), od 2 osób z KDR dodatkowo 30%'],
                           ['Pociągi regionalne', 'rodzice 37% na bilety jednorazowe, 49% na miesięczne'],
                           ['Parki narodowe', 'wstęp bezpłatny'], ['Orlen', '8 gr/l, paliwa premium 10 gr/l'],
                           ['Paszport', 'rodzic 70 zł zamiast 140 zł, dzieci 15 lub 35 zł'],
                           ['Partnerzy w Twoim mieście (%s)' % miasto, 'muzea, baseny, kina: wyszukiwarka na empatia.gov.pl']]

PERSONY = {}

# ---------------------------------------------------------------- Marta Kowalska (dotychczasowa)
PERSONY['marta'] = dict(
    id='marta', plec='K', dop='Marty', okolica='Warszawa-Mokotów', miasto='Warszawa',
    osoba=dict(imie='Marta', nazwisko='Kowalska', pesel='91071427765', data_urodzenia='14.07.1991', miejsce_urodzenia='Warszawa',
               adres='ul. Kwiatowa 12, 02-580 Warszawa (Mokotów)', telefon='+48 601 234 567', email='marta.kowalska@poczta.pl'),
    rodzina=[dict(rola='mąż', imie='Tomasz Kowalski', pesel='89030512357', mobywatel=True),
             dict(rola='syn', imie='Antoni Kowalski', pesel='14250312345', wiek=12, paszport='brak'),
             dict(rola='córka', imie='Zofia Kowalska', pesel='20221104567', wiek=6, paszport='brak'),
             dict(rola='syn', imie='Jan Kowalski', pesel='23282009871', wiek=3, paszport='brak')],
    rodzina_opis='mąż Tomasz, dzieci: Antoni (12), Zofia (6), Jan (3)',
    drugi_rodzic='Tomasz Kowalski', drugi_rodzic_dop='Tomasza Kowalskiego', nazwisko_dziecka=('Kowalska', 'Kowalski'), rodzice='Marta i Tomasz Kowalscy',
    szpital='Szpital Bielański, Warszawa', zameldowanie_krotko='ul. Kwiatowa 12', usc='USC Warszawa',
    dokumenty={'dowod': dict(nazwa='Dowód osobisty', numer='ABC 123456', wydany='20.05.2021', wazny_do='2031-05-20', organ='Prezydent m.st. Warszawy', e_dowod=True),
               'paszport': dict(nazwa='Paszport', numer='EP 4471029', wazny_do='2029-06-30', organ='Wojewoda Mazowiecki'),
               'prawo_jazdy': dict(nazwa='Prawo jazdy', numer='01234/20/1465', wazny_do='2035-06-30', kategorie='B'),
               'kdr': dict(nazwa='Karta Dużej Rodziny', numer='2024/118 554', wazny_do='bezterminowo')},
    paszport_opis='EP 4471029, ważny do 30.06.2029', dzieci_paszporty='brak paszportów',
    pojazdy=[dict(nr='WX 4521K', marka='Toyota Corolla 1.8 Hybrid', model='Toyota Corolla', dop='Toyoty', kolor='srebrny', rok=2021, vin='SB1Z93BE10E215501',
                  oc_do='2026-10-29', ubezpieczyciel='Warta', polisa='908 123 456 789', oc_auto=True, badanie_do='2027-04-12', licznik='58 210 km (12.04.2026)')],
    pojazdy_dawne=['Zgłoszenie zbycia pojazdu Skoda Fabia WX 1180C', 'zakończona 03.2026'],
    wydzial_komunikacji='Urząd m.st. Warszawy, wydział komunikacji',
    urzad='Urząd Dzielnicy Mokotów', urzad_paszportowy='Mazowiecki Urząd Wojewódzki, Warszawa',
    naleznosci=[dict(id='POD-NIER-IV', tytul='Podatek od nieruchomości, IV rata 2026', kwota=210.0, termin='2026-11-16', wierzyciel='Urząd m.st. Warszawy',
                     kanal='eplatnosci', metody=['BLIK', 'karta', 'Apple Pay', 'Google Pay'])],
    mandaty=[],
    skrzynka=[dict(id='US-1', krotko='Pismo z Urzędu Skarbowego', od='Urząd Skarbowy Warszawa-Mokotów', temat='Wezwanie do złożenia wyjaśnień', doreczono='2026-10-17', termin='2026-10-26',
                   tresc='Urząd prosi o udokumentowanie ulgi termomodernizacyjnej z zeznania PIT-37 za 2025 r. (odliczono 32 520 zł) za dom jednorodzinny przy ul. Kwiatowej 12. Wymagane faktury za materiały i usługi.', przeczytana=True),
              dict(id='ZUS-1', od='ZUS', temat='Informacja o stanie konta ubezpieczonego', doreczono='2026-09-30', termin=None, tresc='Roczna informacja o zgromadzonych składkach.', przeczytana=True)],
    pliki=[dict(nazwa='FV 2025/03/118 Termo-Bud.pdf', opis='docieplenie ścian domu, ul. Kwiatowa 12, 18 450,00 zł'),
           dict(nazwa='FV 2025/04/022 Termo-Bud.pdf', opis='styropian i klej, dom ul. Kwiatowa 12, 9 870,00 zł'),
           dict(nazwa='FV 2025/05/301 Okna-Lux.pdf', opis='stolarka okienna, dom ul. Kwiatowa 12, 4 200,00 zł'),
           dict(nazwa='Umowa najmu garażu.pdf', opis='najem garażu przy ul. Kwiatowej 21, od 01.11.2026, wynajmujący: Jerzy Malinowski, 350 zł/mies.')],
    pesel_stan='niezastrzeżony',
    pesel_hist=[['01.03.2024', 'zastrzeżenie (w aplikacji)'], ['10.06.2025', 'cofnięcie zastrzeżenia (kredyt hipoteczny)']],
    pesel_spr=[['02.09.2026', 'mBank S.A., wynik: niezastrzeżony'], ['14.10.2026', 'Plus (Polkomtel), wynik: niezastrzeżony']],
    sprawy=[['Wezwanie US Warszawa-Mokotów (ulga termomodernizacyjna)', 'czeka na Twoją odpowiedź do 26.10.2026'],
            ['Zgłoszenie zbycia pojazdu Skoda Fabia WX 1180C', 'zakończona 03.2026'], ['Karta Dużej Rodziny dla Jana', 'zakończona 09.2024']],
    emerytura=dict(skladki='214 380 zł', subkonto='61 200 zł', wiek=60, tabela={60: 3140, 62: 3730, 65: 4830, 67: 5740}, krok=0.09),
    punkty=dict(punkty=5, limit=24, wykroczenia=[dict(data='12.05.2026', opis='przekroczenie prędkości o 21–25 km/h', punkty=5, wygasaja='12.05.2027')]),
    recepty=[dict(osoba='Zofia (córka)', lek='Amoksiklav 457 mg/5 ml, zawiesina', wazna_do='22.10.2026', kod='4821'),
             dict(osoba='Marta', lek='Letrox 50, tabletki', wazna_do='12.03.2027', kod='7730')],
    kursy=KURSY_W('Warszawa-Mokotów', 'Warszawa-Bemowo', 'Warszawa-Wesoła', 'Legionowo'),
    wybory=dict(obwod='nr 145', lokal='Szkoła Podstawowa nr 98, ul. Kwiatowa 30, Warszawa', krotko='SP nr 98, ul. Kwiatowa 30'),
    firma=dict(ceidg='brak działalności gospodarczej', krs=[dict(podmiot='Stowarzyszenie „Przyjaciele Pola Mokotowskiego"', krs='0000712345', funkcja='członkini zarządu')],
               rows=[['CEIDG', 'brak działalności'], ['KRS 0000712345', 'Stow. „Przyjaciele Pola Mokotowskiego", członkini zarządu']]),
    ksiegi=[dict(numer='WA4M/00412345/6', opis='dom jednorodzinny, ul. Kwiatowa 12', wlasnosc='współwłasność z Tomaszem Kowalskim')],
    partnerzy_kdr=KDR_ULGI('Warszawa'),
    bilety=[dict(przewoznik='PKP Intercity', trasa='Warszawa Centralna → Kraków Główny', kiedy='24.10.2026, 7:15', miejsce='wagon 5, miejsce 43', pociag='IC 5302 „Mehoffer"')],
    konto='PL •• 4412', liczba_osob=5,
    zalatwienia_extra=[],
)

# ---------------------------------------------------------------- Jan Wiśniewski: przedsiębiorca z Krakowa, ojciec trójki
PERSONY['jan'] = dict(
    id='jan', plec='M', dop='Jana', okolica='Kraków-Podgórze', miasto='Kraków',
    osoba=dict(imie='Jan', nazwisko='Wiśniewski', pesel=pesel('830512', '034', 5), data_urodzenia='12.05.1983', miejsce_urodzenia='Kraków',
               adres='ul. Wielicka 28 m. 15, 30-552 Kraków (Podgórze)', telefon='+48 512 345 678', email='jan.wisniewski@poczta.pl'),
    rodzina=[dict(rola='żona', imie='Agnieszka Wiśniewska', pesel=pesel('850918', '112', 8), mobywatel=True),
             dict(rola='syn', imie='Michał Wiśniewski', pesel=pesel('110304', '221', 3), wiek=15, paszport='ważny do 2028'),
             dict(rola='córka', imie='Hanna Wiśniewska', pesel=pesel('152709', '318', 2), wiek=11, paszport='ważny do 2027'),
             dict(rola='syn', imie='Igor Wiśniewski', pesel=pesel('192116', '401', 7), wiek=7, paszport='brak')],
    rodzina_opis='żona Agnieszka, dzieci: Michał (15), Hanna (11), Igor (7)',
    drugi_rodzic='Agnieszka Wiśniewska', drugi_rodzic_dop='Agnieszki Wiśniewskiej', nazwisko_dziecka=('Wiśniewska', 'Wiśniewski'), rodzice='Jan i Agnieszka Wiśniewscy',
    szpital='Szpital Uniwersytecki, Kraków', zameldowanie_krotko='ul. Wielicka 28 m. 15', usc='USC Kraków',
    dokumenty={'dowod': dict(nazwa='Dowód osobisty', numer='CDE 778812', wazny_do='2030-05-20', organ='Prezydent Miasta Krakowa', e_dowod=True),
               'paszport': dict(nazwa='Paszport', numer='EZ 1180442', wazny_do='2031-02-11', organ='Wojewoda Małopolski'),
               'prawo_jazdy': dict(nazwa='Prawo jazdy', numer='00871/12/1261', wazny_do='2033-09-30', kategorie='B, C'),
               'kdr': dict(nazwa='Karta Dużej Rodziny', numer='2021/044 117', wazny_do='bezterminowo')},
    paszport_opis='EZ 1180442, ważny do 11.02.2031', dzieci_paszporty='Michał i Hanna mają paszporty, Igor nie',
    pojazdy=[dict(nr='KR 7G210', marka='Skoda Octavia Combi 2.0 TDI', model='Skoda Octavia Combi', dop='Octavii', kolor='granatowy', rok=2020, vin='TMBJJ7NX5LY061208',
                  oc_do='2027-03-02', ubezpieczyciel='PZU', polisa='1021 448 120', oc_auto=True, badanie_do='2027-01-15', licznik='142 880 km (15.01.2026)'),
             dict(nr='KR 2M884', marka='Volkswagen Transporter T6.1 2.0 TDI', model='Volkswagen Transporter', dop='Transportera', kolor='biały', rok=2022, vin='WV1ZZZ7HZNH004512',
                  oc_do='2026-11-03', ubezpieczyciel='Allianz', polisa='AZ 77 301 455', badanie_do='2027-05-10', licznik='96 400 km (10.05.2026)', firmowy=True,
                  leasing='VW Leasing')],
    pojazdy_dawne=['Leasing Volkswagen Transporter KR 2M884', 'właściciel: VW Leasing, umowa do 05.2027'],
    wydzial_komunikacji='Urząd Miasta Krakowa, wydział komunikacji',
    urzad='Urząd Miasta Krakowa, ul. Wielicka 28a', urzad_paszportowy='Małopolski Urząd Wojewódzki, Kraków',
    naleznosci=[dict(id='ZUS-1026', tytul='Składki społeczne ZUS za 10.2026 (działalność)', kwota=1926.76, termin='2026-11-20', wierzyciel='ZUS, Twój rachunek składkowy',
                     kanal='zus', metody=[]),
                dict(id='POD-NIER-IV', tytul='Podatek od nieruchomości, IV rata 2026', kwota=186.0, termin='2026-11-16', wierzyciel='Urząd Miasta Krakowa',
                     kanal='przelew', metody=[])],
    mandaty=[],
    skrzynka=[dict(id='US-1', krotko='Wyjaśnienia VAT dla Urzędu Skarbowego', od='Urząd Skarbowy Kraków-Podgórze', temat='Wezwanie do złożenia wyjaśnień (czynności sprawdzające, VAT)', doreczono='2026-10-16', termin='2026-10-28',
                   tresc='Urząd prosi o wyjaśnienie, dlaczego w korekcie JPK_V7M za 08.2026 zwiększono podatek naliczony o 4 140 zł z faktury Hurtowni Instal-Mix (KSeF), oraz o dowód zapłaty i protokół dostawy.', przeczytana=True),
              dict(id='CEIDG-1', od='CEIDG', temat='Potwierdzenie zmiany wpisu', doreczono='2026-01-19', termin=None, tresc='Zmiana formy opodatkowania na podatek liniowy od 01.2026 wpisana do CEIDG 19.01.2026.', przeczytana=True)],
    pliki=[dict(nazwa='FV 2026/08/412 Instal-Mix.pdf', opis='materiały instalacyjne, 18 000,00 zł netto, VAT 4 140,00 zł (KSeF)'),
           dict(nazwa='Potwierdzenie przelewu Instal-Mix.pdf', opis='zapłata 22 140,00 zł, 12.08.2026'),
           dict(nazwa='JPK_V7M 08.2026 korekta.xml', opis='korekta deklaracji, wysłana 06.10.2026'),
           dict(nazwa='Umowa leasingu Transporter.pdf', opis='leasing operacyjny, VW Leasing, do 05.2027')],
    pesel_stan='zastrzeżony',
    pesel_hist=[['18.02.2025', 'zastrzeżenie (w aplikacji)']],
    pesel_spr=[['03.10.2026', 'Santander Bank Polska, wynik: zastrzeżony'], ['11.10.2026', 'Play (P4), wynik: zastrzeżony']],
    sprawy=[['Czynności sprawdzające VAT, US Kraków-Podgórze', 'czeka na Twoją odpowiedź do 28.10.2026'],
            ['Wniosek o paszport dla Hanny', 'zakończona 06.2022'], ['Karta Dużej Rodziny dla Igora', 'zakończona 02.2021']],
    emerytura=dict(skladki='386 940 zł', subkonto='72 410 zł', wiek=65, tabela={65: 4380, 67: 5200, 70: 6740}, krok=0.09),
    punkty=dict(punkty=0, limit=24, wykroczenia=[]),
    recepty=[dict(osoba='Igor (syn)', lek='Zyrtec, krople doustne', wazna_do='30.10.2026', kod='5117')],
    kursy=KURSY_W('Kraków-Podgórze', 'Kraków', 'Wieliczka', 'Myślenice'),
    wybory=dict(obwod='nr 312', lokal='Szkoła Podstawowa nr 34, ul. Wielicka 40, Kraków', krotko='SP nr 34, ul. Wielicka 40'),
    firma=dict(ceidg=dict(nazwa='Wiśniewski Instalacje Jan Wiśniewski', nip='6792345679', od='03.2012', pkd='43.22.Z', status='aktywna', vat='czynny podatnik VAT', podatek='liniowy od 01.2026'), krs=[],
               rows=[['CEIDG', 'Wiśniewski Instalacje, aktywna od 03.2012'], ['NIP', '679 234 56 79'], ['PKD', '43.22.Z, instalacje wodno-kanalizacyjne, cieplne, gazowe i klimatyzacyjne'], ['VAT', 'czynny podatnik'], ['Podatek', 'liniowy od 01.2026']]),
    ksiegi=[dict(numer='KR1P/00123456/4', opis='lokal mieszkalny, ul. Wielicka 28 m. 15', wlasnosc='współwłasność z Agnieszką Wiśniewską')],
    partnerzy_kdr=KDR_ULGI('Kraków'),
    bilety=[dict(przewoznik='PKP Intercity', trasa='Kraków Główny → Warszawa Centralna', kiedy='27.10.2026, 6:05', miejsce='wagon 12, miejsce 71', pociag='EIP 1000 „Pendolino"')],
    konto='PL •• 9031', liczba_osob=5,
    zalatwienia_extra=[],
)

# ---------------------------------------------------------------- Ewa Nowak: nauczycielka z Lublina, kilka lat przed emeryturą
PERSONY['ewa'] = dict(
    id='ewa', plec='K', dop='Ewy', okolica='Lublin-Śródmieście', miasto='Lublin',
    osoba=dict(imie='Ewa', nazwisko='Nowak', pesel=pesel('690203', '128', 4), data_urodzenia='03.02.1969', miejsce_urodzenia='Lublin',
               adres='ul. Narutowicza 18 m. 3, 20-016 Lublin', telefon='+48 698 112 054', email='ewa.nowak@poczta.pl'),
    rodzina=[dict(rola='mąż', imie='Krzysztof Nowak', pesel=pesel('660417', '055', 9), mobywatel=True),
             dict(rola='syn', imie='Paweł Nowak', pesel=pesel('940611', '233', 1), wiek=32),
             dict(rola='córka', imie='Magdalena Nowak', pesel=pesel('970822', '149', 6), wiek=29),
             dict(rola='syn', imie='Tomasz Nowak', pesel=pesel('010705', '310', 3), wiek=25),
             dict(rola='mama', imie='Halina Kamińska', pesel=pesel('420119', '077', 0), wiek=84)],
    rodzina_opis='mąż Krzysztof, mama Halina (84 lata)',
    drugi_rodzic='Krzysztof Nowak', drugi_rodzic_dop='Krzysztofa Nowaka', nazwisko_dziecka=('Nowak', 'Nowak'), rodzice='Ewa i Krzysztof Nowakowie',
    szpital='SPSK nr 1, Lublin', zameldowanie_krotko='ul. Narutowicza 18 m. 3', usc='USC Lublin',
    dokumenty={'dowod': dict(nazwa='Dowód osobisty', numer='AXK 552190', wazny_do='2026-12-05', organ='Prezydent Miasta Lublin', e_dowod=False),
               'paszport': dict(nazwa='Paszport', numer='EA 2209174', wazny_do='2019-08-30', organ='Wojewoda Lubelski', uniewazniony=True),
               'prawo_jazdy': dict(nazwa='Prawo jazdy', numer='03311/98/0663', wazny_do='bezterminowo, wymiana do 19.01.2033', kategorie='B'),
               'kdr': dict(nazwa='Karta Dużej Rodziny', numer='2019/302 881', wazny_do='bezterminowo')},
    paszport_opis='EA 2209174, nieważny od 30.08.2019', dzieci_paszporty='dzieci są dorosłe',
    pojazdy=[dict(nr='LU 5521P', marka='Fiat Panda 1.2', model='Fiat Panda', dop='Pandy', kolor='czerwony', rok=2016, vin='ZFA31200003A71188',
                  oc_do='2027-06-14', ubezpieczyciel='Link4', polisa='L4 0071 226 908', oc_auto=True, badanie_do='2026-11-08', licznik='88 140 km (08.11.2025)')],
    pojazdy_dawne=['Zgłoszenie nabycia pojazdu Fiat Panda LU 5521P', 'zakończona 08.2021'],
    wydzial_komunikacji='Urząd Miasta Lublin, wydział komunikacji',
    urzad='Urząd Miasta Lublin, ul. Wieniawska 14', urzad_paszportowy='Lubelski Urząd Wojewódzki, Lublin',
    naleznosci=[dict(id='POD-NIER-IV', tytul='Podatek od nieruchomości, IV rata 2026', kwota=164.0, termin='2026-11-16', wierzyciel='Urząd Miasta Lublin',
                     kanal='eplatnosci', metody=['BLIK'])],
    mandaty=[],
    skrzynka=[dict(id='ZUS-2', od='ZUS', temat='Informacja o stanie konta ubezpieczonego', doreczono='2026-10-15', termin=None,
                   tresc='Wiek emerytalny osiągniesz 03.02.2029. Wniosek o emeryturę (EMP) złożysz najwcześniej 30 dni przed tą datą, czyli od 04.01.2029. Kapitał początkowy: 98 700 zł.', przeczytana=False),
              dict(id='UM-1', od='Urząd Miasta Lublin', temat='Decyzja w sprawie podatku od nieruchomości na 2026 r.', doreczono='2026-02-10', termin=None, tresc='Podatek na 2026 r.: 656 zł w 4 ratach.', przeczytana=True)],
    pliki=[dict(nazwa='Potwierdzenie upoważnienia od mamy (IKP).pdf', opis='Halina Kamińska upoważniła Cię w IKP do wglądu w jej konto, od 05.2024'),
           dict(nazwa='Zaświadczenie o zatrudnieniu SP 24.pdf', opis='nauczycielka dyplomowana, od 09.1993')],
    pesel_stan='niezastrzeżony', pesel_hist=[], pesel_spr=[['20.09.2026', 'PKO BP, wynik: niezastrzeżony']],
    sprawy=[['Dowód osobisty AXK 552190', 'traci ważność 05.12.2026, złóż wniosek do 05.11.2026'],
            ['Upoważnienie od mamy, Haliny Kamińskiej, w IKP', 'aktywne od 05.2024'], ['Karta Dużej Rodziny', 'zakończona 03.2019']],
    emerytura=dict(skladki='512 300 zł', subkonto='41 900 zł', kapital='98 700 zł', wiek=60, tabela={60: 3980, 62: 4730, 65: 6120, 67: 7280}, krok=0.09),
    punkty=dict(punkty=0, limit=24, wykroczenia=[]),
    upowaznienia_ikp=['Halina Kamińska'],  # osoby, które upoważniły użytkowniczkę w IKP
    recepty=[dict(osoba='Ewa', lek='Bisocard 5 mg, tabletki', wazna_do='14.01.2027', kod='3304'),
             dict(osoba='Halina (mama)', lek='Polpril 5 mg, kapsułki', wazna_do='02.11.2026', kod='9182'),
             dict(osoba='Halina (mama)', lek='Atoris 20 mg, tabletki', wazna_do='02.11.2026', kod='9182')],
    kursy=KURSY_W('Lublin-Śródmieście', 'Lublin', 'Świdnik', 'Puławy'),
    wybory=dict(obwod='nr 41', lokal='Szkoła Podstawowa nr 24, ul. Lipowa 10, Lublin', krotko='SP nr 24, ul. Lipowa 10'),
    firma=dict(ceidg='brak działalności gospodarczej', krs=[], rows=[['CEIDG', 'brak działalności'], ['KRS', 'brak funkcji w podmiotach']]),
    ksiegi=[dict(numer='LU1I/00098765/1', opis='lokal mieszkalny, ul. Narutowicza 18 m. 3', wlasnosc='wspólność majątkowa z Krzysztofem Nowakiem')],
    partnerzy_kdr=KDR_ULGI('Lublin'),
    bilety=[dict(przewoznik='PKP Intercity', trasa='Lublin Główny → Warszawa Centralna', kiedy='30.10.2026, 8:12', miejsce='wagon 4, miejsce 26', pociag='IC 3812 „Bystrzyca"')],
    konto='PL •• 2276', liczba_osob=2,
    zalatwienia_extra=[['Emerytura', 'wiek emerytalny 03.02.2029, wniosek złożysz od 04.01.2029']],
)

# ---------------------------------------------------------------- Kacper Zieliński: student z Gdańska, świeże prawo jazdy
PERSONY['kacper'] = dict(
    id='kacper', plec='M', dop='Kacpra', okolica='Gdańsk-Wrzeszcz', miasto='Gdańsk',
    osoba=dict(imie='Kacper', nazwisko='Zieliński', pesel=pesel('062321', '417', 1), data_urodzenia='21.03.2006', miejsce_urodzenia='Elbląg',
               adres='ul. Grunwaldzka 102 m. 7, 80-244 Gdańsk (Wrzeszcz), pobyt czasowy; stały: ul. Ogólna 5, Elbląg', telefon='+48 733 908 211', email='kacper.zielinski@student.pg.edu.pl'),
    rodzina=[dict(rola='mama', imie='Anna Zielińska', pesel=pesel('780302', '210', 6), mobywatel=True),
             dict(rola='tata', imie='Robert Zieliński', pesel=pesel('760915', '144', 3), mobywatel=True),
             dict(rola='siostra', imie='Ola Zielińska', pesel=pesel('102208', '355', 4), wiek=16)],
    rodzina_opis='rodzice Anna i Robert (Elbląg)',
    drugi_rodzic='', drugi_rodzic_dop='', nazwisko_dziecka=('Zielińska', 'Zieliński'), rodzice='Kacper Zieliński',
    szpital='Szpital Kliniczny UCK, Gdańsk', zameldowanie_krotko='ul. Grunwaldzka 102 m. 7', usc='USC Gdańsk',
    dokumenty={'dowod': dict(nazwa='Dowód osobisty', numer='DFT 220419', wazny_do='2034-04-02', organ='Prezydent Miasta Elbląg', e_dowod=True),
               'prawo_jazdy': dict(nazwa='Prawo jazdy', numer='00512/26/2861', wazny_do='2041-01-14', kategorie='B', wydane='14.01.2026', okres_probny='do 14.01.2028'),
               'legitymacja': dict(nazwa='Legitymacja studencka', numer='198442', wazny_do='2027-03-31', uczelnia='Politechnika Gdańska')},
    paszport_opis='brak paszportu, do krajów UE wystarczy dowód', dzieci_paszporty='nie dotyczy',
    pojazdy=[dict(nr='GD 8K113', marka='Volkswagen Golf IV 1.4', model='Volkswagen Golf IV', dop='Golfa', kolor='czarny', rok=2003, vin='WVWZZZ1JZ3W512288',
                  oc_do='2027-02-01', ubezpieczyciel='Ergo Hestia', polisa='EH 330 128 774', oc_auto=True, badanie_do='2027-01-20', licznik='251 300 km (20.01.2026)')],
    pojazdy_dawne=['Zgłoszenie nabycia pojazdu Volkswagen Golf GD 8K113', 'zakończona 02.2026'],
    wydzial_komunikacji='Urząd Miejski w Gdańsku, wydział komunikacji',
    urzad='Urząd Miejski w Gdańsku, ul. Partyzantów 74', urzad_paszportowy='Pomorski Urząd Wojewódzki, Gdańsk',
    naleznosci=[dict(id='MK-1029', tytul='Mandat karny MK 2026/1 840 212 (prędkość)', kwota=200.0, termin='2026-10-22', wierzyciel='Policja, Pomorski Urząd Wojewódzki',
                     kanal='mandat', metody=[])],
    mandaty=[dict(numer='MK 2026/1 840 212', kwota='200 zł', termin='22.10.2026', data='15.10.2026', opis='przekroczenie prędkości o 18 km/h (16–20 km/h), Gdańsk, al. Grunwaldzka',
                  punkty=3, organ='Komenda Miejska Policji w Gdańsku', odbiorca='Pomorski Urząd Wojewódzki', jak_zaplacic='przelew według instrukcji z mandatu, 7 dni od wręczenia')],
    skrzynka=[dict(id='PG-1', od='Politechnika Gdańska', temat='Decyzja o przyznaniu stypendium rektora', doreczono='2026-10-14', termin=None,
                   tresc='Stypendium rektora na rok akademicki 2026/2027: 1 100 zł miesięcznie, od października 2026.', przeczytana=False)],
    pliki=[dict(nazwa='Umowa najmu pokoju Grunwaldzka.pdf', opis='pokój przy ul. Grunwaldzkiej 102 m. 7, 1 250 zł/mies., do 30.06.2027'),
           dict(nazwa='Umowa kupna Golf.pdf', opis='zakup VW Golf IV od Mariusza Lewandowskiego, 7 500 zł, 02.2026')],
    pesel_stan='niezastrzeżony', pesel_hist=[], pesel_spr=[['01.10.2026', 'Revolut, wynik: niezastrzeżony']],
    sprawy=[['Mandat karny MK 2026/1 840 212', 'do zapłaty 200 zł do 22.10.2026'], ['Zgłoszenie nabycia pojazdu VW Golf GD 8K113', 'zakończona 02.2026'],
            ['Zameldowanie czasowe w Gdańsku', 'zakończona 10.2025']],
    emerytura=dict(skladki='6 240 zł', subkonto='1 180 zł', wiek=65, tabela={65: 3920, 67: 4660, 70: 6030}, krok=0.09),
    punkty=dict(punkty=3, limit=20, pierwszy_rok_do='14.01.2027', limit_potem=24, okres_probny='do 14.01.2028',
                wykroczenia=[dict(data='15.10.2026', opis='przekroczenie prędkości o 16–20 km/h', punkty=3, wygasaja='rok po opłaceniu mandatu', mandat='MK-1029')]),
    recepty=[],
    kursy=KURSY_W('Gdańsk-Wrzeszcz', 'Gdynia', 'Gdańsk', 'Wejherowo'),
    wybory=dict(obwod='nr 7 w Elblągu', lokal='Szkoła Podstawowa nr 11, ul. Ogólna 20, Elbląg', krotko='SP nr 11, Elbląg (miejsce zameldowania na stałe)'),
    firma=dict(ceidg='brak działalności gospodarczej', krs=[], rows=[['CEIDG', 'brak działalności'], ['KRS', 'brak funkcji w podmiotach']]),
    ksiegi=[],
    partnerzy_kdr=[],
    bilety=[dict(przewoznik='Polregio', trasa='Gdańsk Główny → Elbląg', kiedy='31.10.2026, 15:42', miejsce='bez rezerwacji', pociag='R 50124, ulga studencka 51%')],
    konto='PL •• 6610', liczba_osob=1,
    zalatwienia_extra=[['Miejsce głosowania', 'jesteś w rejestrze w Elblągu, możesz na stałe przepisać się do obwodu w Gdańsku']],
)

DOMYSLNA = 'marta'

# ---------------------------------------------------------------- TRYB ALARMOWY
# Ta sama osoba (imię, nazwisko, zdjęcie), ale inne dane identyfikacyjne: PESEL, numery dokumentów, rejestracje, polisy, telefon, adres.
# Włącza go klient: osoba='marta:alarm'. Te same podmiany są w osoby.js (karty w aplikacji).
import re as _re
ALARM_PODMIANY = {
 "marta": [
  [
   "ABC 123456",
   "KLM 740915"
  ],
  [
   "01234/20/1465",
   "05261/19/0873"
  ],
  [
   "2024/118 554",
   "2023/207 316"
  ],
  [
   "908 123 456 789",
   "764 310 928 415"
  ],
  [
   "WX 4521K",
   "WB 7392L"
  ],
  [
   "WX 1180C",
   "WB 2046D"
  ],
  [
   "EP 4471029",
   "EK 6038417"
  ],
  [
   "SB1Z93BE10E215501",
   "SB1Z93BE70E384726"
  ],
  [
   "PL •• 4412",
   "PL •• 8057"
  ],
  [
   "0000712345",
   "0000598301"
  ],
  [
   "WA4M/00412345/6",
   "WA4M/00538210/2"
  ],
  [
   "+48 601 234 567",
   "+48 609 871 204"
  ],
  [
   "marta.kowalska@poczta.pl",
   "m.kowalska@poczta.pl"
  ],
  [
   "Kwiatowa 12",
   "Kwiatowa 27"
  ],
  [
   "Kwiatowej 12",
   "Kwiatowej 27"
  ]
 ],
 "jan": [
  [
   "00871/12/1261",
   "01459/14/0382"
  ],
  [
   "1021 448 120",
   "1387 205 764"
  ],
  [
   "2021/044 117",
   "2022/091 538"
  ],
  [
   "CDE 778812",
   "FGH 305491"
  ],
  [
   "KR 7G210",
   "KR 4P825"
  ],
  [
   "KR 2M884",
   "KR 9T173"
  ],
  [
   "6792345679",
   "5261184305"
  ],
  [
   "679 234 56 79",
   "526 118 43 05"
  ],
  [
   "77 301 455",
   "36 912 804"
  ],
  [
   "EZ 1180442",
   "EX 5307719"
  ],
  [
   "WV1ZZZ7HZNH004512",
   "WV1ZZZ7HZNH027741"
  ],
  [
   "TMBJJ7NX5LY061208",
   "TMBJJ7NX5LY093357"
  ],
  [
   "KR1P/00123456/4",
   "KR1P/00277190/8"
  ],
  [
   "PL •• 9031",
   "PL •• 3365"
  ],
  [
   "+48 512 345 678",
   "+48 518 207 463"
  ],
  [
   "jan.wisniewski@poczta.pl",
   "j.wisniewski@poczta.pl"
  ],
  [
   "Wielicka 28",
   "Wielicka 34"
  ]
 ],
 "ewa": [
  [
   "0071 226 908",
   "0183 540 276"
  ],
  [
   "03311/98/0663",
   "02947/97/0512"
  ],
  [
   "2019/302 881",
   "2018/417 092"
  ],
  [
   "AXK 552190",
   "BKT 316748"
  ],
  [
   "EA 2209174",
   "EB 7731056"
  ],
  [
   "LU 5521P",
   "LU 8140R"
  ],
  [
   "LU1I/00098765/1",
   "LU1I/00154208/5"
  ],
  [
   "PL •• 2276",
   "PL •• 5913"
  ],
  [
   "ZFA31200003A71188",
   "ZFA31200003A92465"
  ],
  [
   "+48 698 112 054",
   "+48 692 540 318"
  ],
  [
   "ewa.nowak@poczta.pl",
   "e.nowak@poczta.pl"
  ],
  [
   "Narutowicza 18",
   "Narutowicza 26"
  ]
 ],
 "kacper": [
  [
   "00512/26/2861",
   "00734/26/1195"
  ],
  [
   "DFT 220419",
   "DGW 584036"
  ],
  [
   "EH 330 128 774",
   "EH 471 905 362"
  ],
  [
   "GD 8K113",
   "GD 3M672"
  ],
  [
   "PL •• 6610",
   "PL •• 2184"
  ],
  [
   "WVWZZZ1JZ3W512288",
   "WVWZZZ1JZ3W640915"
  ],
  [
   "198442",
   "204517"
  ],
  [
   "MK 2026/1 840 212",
   "MK 2026/1 627 305"
  ],
  [
   "+48 733 908 211",
   "+48 735 416 092"
  ],
  [
   "kacper.zielinski@student.pg.edu.pl",
   "k.zielinski@student.pg.edu.pl"
  ],
  [
   "Grunwaldzka 102",
   "Grunwaldzka 87"
  ],
  [
   "Grunwaldzkiej 102",
   "Grunwaldzkiej 87"
  ]
 ]
}

def _pesel_alarm(s):
    def f(m):
        d = [int(c) for c in m.group(0)]
        for i in (6, 7, 8): d[i] = (d[i] * 3 + 5) % 10
        w = [1, 3, 7, 9, 1, 3, 7, 9, 1, 3]
        d[10] = (10 - sum(d[i] * w[i] for i in range(10)) % 10) % 10
        return ''.join(map(str, d))
    return _re.sub(r'\b\d{11}\b', f, s)

def _alarmuj(x, osoba_id):
    if isinstance(x, str):
        s = _pesel_alarm(x)
        for a, b in ALARM_PODMIANY.get(osoba_id, []): s = s.replace(a, b)
        return s
    if isinstance(x, dict): return {k: _alarmuj(v, osoba_id) for k, v in x.items()}
    if isinstance(x, list): return [_alarmuj(v, osoba_id) for v in x]
    if isinstance(x, tuple): return tuple(_alarmuj(v, osoba_id) for v in x)
    return x

_alarm_cache = {}
_ctx = threading.local()
def ustaw(osoba):
    alarm = isinstance(osoba, str) and osoba.endswith(':alarm')
    base = osoba[:-6] if alarm else osoba
    p = PERSONY.get(base or DOMYSLNA, PERSONY[DOMYSLNA])
    if alarm:
        if p['id'] not in _alarm_cache: _alarm_cache[p['id']] = _alarmuj(p, p['id'])
        p = _alarm_cache[p['id']]
    _ctx.p = p
    return p
def P():
    p = getattr(_ctx, 'p', None)
    return p if p is not None else PERSONY[DOMYSLNA]
